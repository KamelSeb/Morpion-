class Boardcase
  attr :position, :pawn


    def initialize(position, pawn)
      @position = position.to_s
      @pawn = pawn.to_s
    end

end  

